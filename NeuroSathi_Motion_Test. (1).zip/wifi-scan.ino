
#include <Wire.h>

const int SDA_PIN = 21;
const int SCL_PIN = 22;
const int MPU_ADDR = 0x68;

int16_t prevX, prevY, prevZ;
bool firstReading = true;

void writeMPU(byte reg, byte value) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();
}

int16_t readAxis(byte reg) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);

  Wire.requestFrom(MPU_ADDR, 2, true);
  if (Wire.available() < 2) return 0;

  int16_t highByte = Wire.read();
  int16_t lowByte = Wire.read();

  return (highByte << 8) | lowByte;
}

void setup() {
  Serial.begin(115200);
  Wire.begin(SDA_PIN, SCL_PIN);

  writeMPU(0x6B, 0x00);
  delay(100);

  Serial.println("NeuroSathi Motion Test Started");
}

void loop() {
  int16_t x = readAxis(0x3B);
  int16_t y = readAxis(0x3D);
  int16_t z = readAxis(0x3F);

  Serial.print("X: ");
  Serial.print(x);
  Serial.print("  Y: ");
  Serial.print(y);
  Serial.print("  Z: ");
  Serial.println(z);

  if (!firstReading) {
    int changeX = abs((int)x - prevX);
    int changeY = abs((int)y - prevY);
    int changeZ = abs((int)z - prevZ);

    if (changeX > 1500 ||
        changeY > 1500 ||
        changeZ > 1500) {
      Serial.println("Movement change detected!");
    }
  }

  prevX = x;
  prevY = y;
  prevZ = z;
  firstReading = false;

  delay(300);
}
