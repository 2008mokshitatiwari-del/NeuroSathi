
#include <Wire.h>

const int SDA_PIN = 21;
const int SCL_PIN = 22;
const int MPU_ADDR = 0x68;

void writeMPU(byte reg, byte value) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();
}

int16_t readAxis(byte reg) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_ADDR, 2, true);

  if (Wire.available() < 2) return 0;

  int16_t highByte = Wire.read();
  int16_t lowByte = Wire.read();

  return (highByte << 8) | lowByte;
}

void setup() {
  Serial.begin(115200);
  Wire.begin(SDA_PIN, SCL_PIN);

  // Wake up MPU6050
  writeMPU(0x6B, 0x00);
  delay(100);

  Serial.println("NeuroSathi sensor test started");
}

void loop() {
  int16_t ax = readAxis(0x3B);
  int16_t ay = readAxis(0x3D);
  int16_t az = readAxis(0x3F);

  Serial.print("X: ");
  Serial.print(ax);
  Serial.print("  Y: ");
  Serial.print(ay);
  Serial.print("  Z: ");
  Serial.println(az);

  delay(500);
}
